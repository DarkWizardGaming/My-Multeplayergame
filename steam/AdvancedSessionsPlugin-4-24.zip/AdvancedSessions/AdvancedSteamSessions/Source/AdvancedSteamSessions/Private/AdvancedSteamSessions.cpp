//#include "StandAlonePrivatePCH.h"
#include "AdvancedSteamSessions.h"

void AdvancedSteamSessions::StartupModule()
{
}
 
void AdvancedSteamSessions::ShutdownModule()
{
}
 
IMPLEMENT_MODULE(AdvancedSteamSessions, AdvancedSteamSessions)